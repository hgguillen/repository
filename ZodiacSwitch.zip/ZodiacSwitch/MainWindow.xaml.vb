﻿Class MainWindow

    Sub RunCode(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles BtnGo.Click
        Dim Year As String = TextInput.Text

        Select Case Year
            Case 2008, 1996, 1984, 1972, 1960
                Output("You are born in Year of the Rat")
            Case 2009, 1997, 1985, 1973, 1961
                Output("You are born in the Year of Ox")
            Case 2010, 1998, 1986, 1974, 1962
                Output("You are born in the Year of Tiger")
            Case 2011, 1999, 1987, 1975, 1963
                Output("You are born in the Year of Rabbit")
            Case 2012, 2000, 1988, 1976, 1964
                Output("You are born in the Year of Dragon")
            Case 2013, 2001, 1989, 1977, 1965
                Output("You are born in the Year of Snake")
            Case 2014, 2002, 1990, 1978, 1966
                Output("You are born in the Year of Horse")
            Case 2015, 2003, 1991, 1979, 1967
                Output("You are born in the Year of Goat")
            Case 2016, 2004, 1992, 1980, 1968
                Output("You are born in the Year of Monkey")
            Case 2017, 2005, 1993, 1981, 1969
                Output("You are born in the Year of Rooster")
            Case 2018, 2006, 1994, 1982, 1970
                Output("You are born in the Year of Dog")
            Case 2019, 2007, 1995, 1983, 1971
                Output("You are born in the Year of Pig")
        End Select


    End Sub

    Sub ClearOutput(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles BtnClear.Click
        TextOutput.Text = ""
    End Sub

    Sub Output(ByVal Value As String)
        TextOutput.Text += Value + vbCrLf
    End Sub
End Class
